"""
db.py  –  Capa de acceso a datos para PropiFacturacion
Regla: NUNCA construir SQL con concatenación de strings.
       Siempre usar parámetros con pyodbc (signo ?) o ejecutar SPs con EXEC.
"""
import configparser
import os
import pyodbc


# ── Cargar configuración ──────────────────────────────────────────────────────
_cfg = configparser.ConfigParser()
_cfg_path = os.path.join(os.path.dirname(__file__), "config.ini")
_cfg.read(_cfg_path, encoding="utf-8")

_SERVER   = _cfg["database"]["server"]
_DATABASE = _cfg["database"]["database"]
_USUARIO  = _cfg["database"]["usuario"]
_CLAVE    = _cfg["database"]["contrasena"]
_DRIVER   = _cfg["database"]["driver"]

_conn: pyodbc.Connection | None = None   # conexión global de sesión
_cod_acceso: int | None = None           # ID del registro de BitacoraAcceso activo


# ── Conexión ──────────────────────────────────────────────────────────────────
def conectar() -> pyodbc.Connection:
    """Abre (o reutiliza) la conexión a SQL Server."""
    global _conn
    if _conn is None:
        cadena = (
            f"DRIVER={{{_DRIVER}}};"
            f"SERVER={_SERVER};"
            f"DATABASE={_DATABASE};"
            f"UID={_USUARIO};"
            f"PWD={_CLAVE};"
            "TrustServerCertificate=yes;"
        )
        _conn = pyodbc.connect(cadena, autocommit=False)
    return _conn


def desconectar():
    """Cierra la conexión limpiamente."""
    global _conn
    if _conn:
        try:
            _conn.close()
        finally:
            _conn = None


# ── Helpers internos ──────────────────────────────────────────────────────────
def _cursor():
    return conectar().cursor()


def _ejecutar_sp(nombre_sp: str, **params) -> list[dict]:
    """
    Ejecuta un SP con parámetros con nombre.
    Retorna lista de filas como dicts.  Si el SP no retorna filas, retorna [].
    """
    conn = conectar()
    cur = conn.cursor()
    pares = ", ".join(f"@{k}=?" for k in params)
    sql   = f"SET NOCOUNT ON; EXEC {nombre_sp} {pares}"
    cur.execute(sql, list(params.values()))
    # Avanzar por todos los result sets intermedios hasta llegar al que tiene datos
    filas = []
    while True:
        try:
            if cur.description:
                cols = [d[0] for d in cur.description]
                for fila in cur.fetchall():
                    filas.append(dict(zip(cols, fila)))
                if filas:
                    break
        except TypeError:
            pass
        try:
            if not cur.nextset():
                break
        except Exception:
            break
    conn.commit()
    return filas


def _ejecutar_sp_sin_params(nombre_sp: str) -> list[dict]:
    conn = conectar()
    cur  = conn.cursor()
    cur.execute(f"SET NOCOUNT ON; EXEC {nombre_sp}")
    filas = []
    while True:
        try:
            if cur.description:
                cols = [d[0] for d in cur.description]
                for fila in cur.fetchall():
                    filas.append(dict(zip(cols, fila)))
                if filas:
                    break
        except TypeError:
            pass
        try:
            if not cur.nextset():
                break
        except Exception:
            break
    conn.commit()
    return filas


# ── Sesión ────────────────────────────────────────────────────────────────────
def registrar_acceso(nom_terminal: str, dir_ip: str) -> int:
    """
    Llama a app.usp_Acceso_Registrar.
    Retorna el cod_acceso generado (guardado globalmente para el logout).
    """
    global _cod_acceso
    filas = _ejecutar_sp(
        "app.usp_Acceso_Registrar",
        nom_terminal=nom_terminal,
        dir_ip=dir_ip,
    )
    if filas:
        _cod_acceso = filas[0].get("cod_acceso")
    return _cod_acceso


def cerrar_acceso():
    """Llama a app.usp_Acceso_Cerrar para registrar la salida."""
    global _cod_acceso
    if _cod_acceso:
        _ejecutar_sp("app.usp_Acceso_Cerrar", cod_acceso=_cod_acceso)
        _cod_acceso = None


# ── Catálogos ─────────────────────────────────────────────────────────────────
def listar_tipos_identificacion() -> list[dict]:
    return _ejecutar_sp_sin_params("app.usp_TipoIdentificacion_Listar")


def listar_tipos_impuesto() -> list[dict]:
    return _ejecutar_sp_sin_params("app.usp_TipoImpuesto_Listar")


# ── Clientes ──────────────────────────────────────────────────────────────────
def listar_clientes(filtro_nombre: str = "", estado: str = "A") -> list[dict]:
    # El SP solo filtra por estado; el filtro por nombre/identificación
    # se aplica aquí sobre los datos ya desencriptados que devuelve el SP.
    filas = _ejecutar_sp("app.usp_Cliente_Listar", ind_estado=estado)
    txt = filtro_nombre.strip().lower()
    if txt:
        filas = [
            f for f in filas
            if txt in str(f.get("nom_cliente", "")).lower()
            or txt in str(f.get("num_identificacion", "")).lower()
        ]
    return filas


def obtener_cliente(cod_cliente: int) -> dict | None:
    filas = _ejecutar_sp("app.usp_Cliente_Obtener", cod_cliente=cod_cliente)
    return filas[0] if filas else None


def insertar_cliente(
    nom_cliente: str,
    cod_tipo_identificacion: int,
    num_identificacion: str,
    nom_provincia: str,
    nom_canton: str,
    nom_distrito: str,
    des_correo: str,
    nom_barrio: str = "",
    des_profesion: str = "",
    des_actividad_economica: str = "",
    num_telefono: str = "",
) -> int:
    """Retorna el cod_cliente del registro creado."""
    filas = _ejecutar_sp(
        "app.usp_Cliente_Insertar",
        nom_cliente=nom_cliente,
        cod_tipo_identificacion=cod_tipo_identificacion,
        num_identificacion=num_identificacion,
        nom_provincia=nom_provincia,
        nom_canton=nom_canton,
        nom_distrito=nom_distrito,
        nom_barrio=nom_barrio or None,
        des_profesion=des_profesion or None,
        des_actividad_economica=des_actividad_economica or None,
        des_correo=des_correo,
        num_telefono=num_telefono or None,
    )
    return filas[0]["cod_cliente"] if filas else None


def actualizar_cliente(
    cod_cliente: int,
    nom_cliente: str,
    cod_tipo_identificacion: int,
    num_identificacion: str,
    ind_estado: str,
    nom_provincia: str,
    nom_canton: str,
    nom_distrito: str,
    des_correo: str,
    nom_barrio: str = "",
    des_profesion: str = "",
    des_actividad_economica: str = "",
    num_telefono: str = "",
) -> None:
    _ejecutar_sp(
        "app.usp_Cliente_Actualizar",
        cod_cliente=cod_cliente,
        nom_cliente=nom_cliente,
        cod_tipo_identificacion=cod_tipo_identificacion,
        num_identificacion=num_identificacion,
        nom_provincia=nom_provincia,
        nom_canton=nom_canton,
        nom_distrito=nom_distrito,
        nom_barrio=nom_barrio or None,
        des_profesion=des_profesion or None,
        des_actividad_economica=des_actividad_economica or None,
        des_correo=des_correo,
        num_telefono=num_telefono or None,
        ind_estado=ind_estado,
    )


# ── Productos ─────────────────────────────────────────────────────────────────
def listar_productos(estado: str = "A") -> list[dict]:
    return _ejecutar_sp("app.usp_Producto_Listar", ind_estado=estado)


def obtener_producto(cod_producto: int) -> dict | None:
    filas = _ejecutar_sp("app.usp_Producto_Obtener", cod_producto=cod_producto)
    return filas[0] if filas else None


# ── Facturas ──────────────────────────────────────────────────────────────────
def listar_facturas(
    cod_cliente: int | None = None,
    fecha_desde: str = "",
    fecha_hasta: str = "",
) -> list[dict]:
    return _ejecutar_sp(
        "app.usp_Factura_Listar",
        fec_desde=fecha_desde or None,
        fec_hasta=fecha_hasta or None,
    )


def obtener_factura(num_factura: int) -> dict | None:
    filas = _ejecutar_sp("app.usp_Factura_Obtener", num_factura=num_factura)
    return filas[0] if filas else None


def insertar_factura(
    cod_cliente: int,
    ind_condicion_venta: str,
    ind_medio_pago: str,
    cod_moneda: str,
    mon_tipo_cambio: float,
    des_observaciones: str,
    lineas: list[dict],       # [{"cod_producto": int, "num_cantidad": float}, ...]
) -> int:
    """
    Inserta una factura con sus líneas.
    Usa una tabla temporal + INSERT + EXEC para pasar el TVP.
    Retorna num_factura.
    """
    conn = conectar()
    cur  = conn.cursor()

    # Crear tabla temporal para el TVP
    cur.execute("""
        IF OBJECT_ID('tempdb..#detalle_tmp') IS NOT NULL DROP TABLE #detalle_tmp;
        CREATE TABLE #detalle_tmp (
            cod_producto  INT            NOT NULL,
            num_cantidad  DECIMAL(12,2)  NOT NULL
        );
    """)

    for linea in lineas:
        cur.execute(
            "INSERT INTO #detalle_tmp (cod_producto, num_cantidad) VALUES (?, ?)",
            linea["cod_producto"], linea["num_cantidad"],
        )

    # Llamar al SP pasando el TVP desde la tabla temporal
    cur.execute("""
        SET NOCOUNT ON;
        DECLARE @det app.TD_FacturaDetalle;
        INSERT INTO @det SELECT cod_producto, num_cantidad FROM #detalle_tmp;
        EXEC app.usp_Factura_Insertar
            @cod_cliente         = ?,
            @ind_condicion_venta = ?,
            @ind_medio_pago      = ?,
            @cod_moneda          = ?,
            @mon_tipo_cambio     = ?,
            @des_observaciones   = ?,
            @detalle             = @det;
    """,
        cod_cliente, ind_condicion_venta, ind_medio_pago,
        cod_moneda, mon_tipo_cambio, des_observaciones or None,
    )

    num_factura = None
    try:
        fila = cur.fetchone()
        if fila:
            num_factura = fila[0]
    except Exception:
        pass

    conn.commit()
    return num_factura


# ── Notas de crédito/débito ───────────────────────────────────────────────────
def listar_notas(num_factura: int | None = None) -> list[dict]:
    return _ejecutar_sp("app.usp_Nota_Listar", num_factura=num_factura)


def insertar_nota(num_factura: int, ind_tipo: str, des_motivo: str) -> None:
    _ejecutar_sp(
        "app.usp_Nota_Insertar",
        num_factura=num_factura,
        ind_tipo=ind_tipo,
        des_motivo=des_motivo,
    )


# ── Reportes ──────────────────────────────────────────────────────────────────
def reporte_clientes() -> list[dict]:
    return _ejecutar_sp_sin_params("app.usp_Reporte_ClientesResumido")


def reporte_facturas(
    cod_cliente: int | None = None,
    fecha_desde: str = "",
    fecha_hasta: str = "",
) -> list[dict]:
    return _ejecutar_sp(
        "app.usp_Reporte_Facturas",
        cod_cliente=cod_cliente,
        fecha_desde=fecha_desde or None,
        fecha_hasta=fecha_hasta or None,
    )


def reporte_pistas_auditoria(
    cod_tabla: str = "",
    ind_accion: str = "",
    fecha_desde: str = "",
    fecha_hasta: str = "",
) -> list[dict]:
    return _ejecutar_sp(
        "app.usp_Reporte_PistasAuditoria",
        cod_tabla=cod_tabla or None,
        ind_accion=ind_accion or None,
        fecha_desde=fecha_desde or None,
        fecha_hasta=fecha_hasta or None,
    )
