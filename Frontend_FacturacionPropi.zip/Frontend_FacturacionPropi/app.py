"""
app.py  –  Frontend principal de PropiFacturacion
Tecnología: Python 3.11+ + tkinter (incluido en Python, sin instalar nada extra)
Dependencia externa única: pyodbc  →  pip install pyodbc

Estructura de ventanas:
  LoginWindow  → MainWindow
    ├── Tab Clientes   (listar, nuevo, editar)
    ├── Tab Facturas   (listar, nueva factura con líneas)
    ├── Tab Notas      (listar, nueva nota sobre factura)
    └── Tab Reportes   (clientes, facturas, auditoría)
"""

import socket
import tkinter as tk
from tkinter import messagebox, ttk

import db

# ── Paleta de colores ─────────────────────────────────────────────────────────
BG_MAIN    = "#F5F4F0"
BG_FRAME   = "#FFFFFF"
FG_MAIN    = "#1A1A18"
FG_SUB     = "#5A5A52"
COLOR_ACC  = "#1D5FA8"
COLOR_ERR  = "#A81D1D"
FONT_H1    = ("Segoe UI", 14, "bold")
FONT_H2    = ("Segoe UI", 11, "bold")
FONT_BODY  = ("Segoe UI", 10)
FONT_MONO  = ("Consolas", 10)


# ══════════════════════════════════════════════════════════════════════════════
#  UTILIDADES DE UI
# ══════════════════════════════════════════════════════════════════════════════
def _lbl(parent, texto, **kw):
    return tk.Label(parent, text=texto, bg=BG_FRAME, fg=FG_MAIN,
                    font=FONT_BODY, **kw)


def _btn(parent, texto, comando, color=COLOR_ACC):
    return tk.Button(
        parent, text=texto, command=comando,
        bg=color, fg="white", font=("Segoe UI", 10, "bold"),
        relief="flat", padx=12, pady=5, cursor="hand2",
        activebackground="#174E8A", activeforeground="white",
    )


def _entry(parent, **kw):
    return tk.Entry(parent, font=FONT_BODY, relief="solid", bd=1, **kw)


def _tabla(parent, columnas: list[str], alto=12):
    """Crea un Treeview con scrollbar."""
    frame = tk.Frame(parent, bg=BG_FRAME)
    tv = ttk.Treeview(frame, columns=columnas, show="headings", height=alto)
    for c in columnas:
        tv.heading(c, text=c)
        tv.column(c, width=max(80, len(c)*10), minwidth=60)
    sb_y = ttk.Scrollbar(frame, orient="vertical",   command=tv.yview)
    sb_x = ttk.Scrollbar(frame, orient="horizontal", command=tv.xview)
    tv.configure(yscrollcommand=sb_y.set, xscrollcommand=sb_x.set)
    tv.grid(row=0, column=0, sticky="nsew")
    sb_y.grid(row=0, column=1, sticky="ns")
    sb_x.grid(row=1, column=0, sticky="ew")
    frame.grid_rowconfigure(0, weight=1)
    frame.grid_columnconfigure(0, weight=1)
    return frame, tv


def _poblar_tabla(tv: ttk.Treeview, filas: list[dict]):
    tv.delete(*tv.get_children())
    if filas:
        # Las columnas se ajustan a lo que realmente devuelve el SP,
        # así encabezados y datos siempre coinciden.
        cols = list(filas[0].keys())
        tv["columns"] = cols
        for c in cols:
            tv.heading(c, text=c)
            tv.column(c, width=max(90, len(c) * 10), minwidth=60)
    for f in filas:
        tv.insert("", "end", values=["" if v is None else v for v in f.values()])


def _form_campo(parent, row, etiqueta, valor="", ancho=30) -> tk.Entry:
    _lbl(parent, etiqueta + ":").grid(row=row, column=0, sticky="e", padx=(0, 8), pady=4)
    e = _entry(parent, width=ancho)
    e.insert(0, "" if valor is None else str(valor))   # los NULL de la BD llegan como None
    e.grid(row=row, column=1, sticky="w", pady=4)
    return e


# ══════════════════════════════════════════════════════════════════════════════
#  VENTANA DE LOGIN
# ══════════════════════════════════════════════════════════════════════════════
class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Propi — Iniciar sesión")
        self.configure(bg=BG_MAIN)
        self.resizable(False, False)
        self._build()
        self.eval("tk::PlaceWindow . center")

    def _build(self):
        frame = tk.Frame(self, bg=BG_FRAME, padx=40, pady=36, relief="flat")
        frame.pack(padx=32, pady=32)

        tk.Label(frame, text="Propi Facturación", font=FONT_H1,
                 bg=BG_FRAME, fg=COLOR_ACC).grid(row=0, column=0, columnspan=2, pady=(0, 20))

        tk.Label(frame, text="Estado:", bg=BG_FRAME, fg=FG_SUB,
                 font=FONT_BODY).grid(row=1, column=0, columnspan=2)
        self.lbl_estado = tk.Label(frame, text="Conectando…", bg=BG_FRAME,
                                   fg=FG_SUB, font=FONT_BODY)
        self.lbl_estado.grid(row=2, column=0, columnspan=2, pady=(0, 16))

        _lbl(frame, "Usuario (config.ini):").grid(row=3, column=0, sticky="e", padx=(0,8), pady=4)
        self.lbl_user = tk.Label(frame, text="—", bg=BG_FRAME, fg=COLOR_ACC, font=FONT_BODY)
        self.lbl_user.grid(row=3, column=1, sticky="w")

        btn = _btn(frame, "Ingresar al sistema", self._login)
        btn.grid(row=4, column=0, columnspan=2, pady=(20, 0))

        self.after(100, self._verificar_conexion)

    def _verificar_conexion(self):
        try:
            conn = db.conectar()
            import configparser, os
            cfg = configparser.ConfigParser()
            cfg.read(os.path.join(os.path.dirname(__file__), "config.ini"), encoding="utf-8")
            self.lbl_user.config(text=cfg["database"]["usuario"])
            self.lbl_estado.config(text="✓ Conexión OK", fg="#3A8A1D")
        except Exception as e:
            self.lbl_estado.config(text=f"✗ Error: {e}", fg=COLOR_ERR)

    def _login(self):
        try:
            terminal = socket.gethostname()
            ip = socket.gethostbyname(terminal)
            cod = db.registrar_acceso(terminal, ip)
            self.withdraw()
            # El mainloop de esta ventana raíz sigue atendiendo a la principal;
            # tanto "Cerrar sesión" como la X de la ventana regresan al login.
            MainWindow(self)
        except Exception as e:
            self.deiconify()
            messagebox.showerror("Error de acceso", str(e))

    def volver(self):
        """Muestra de nuevo el login (se llama al cerrar sesión)."""
        self.deiconify()
        self.lbl_estado.config(text="Conectando…", fg=FG_SUB)
        self.after(100, self._verificar_conexion)


# ══════════════════════════════════════════════════════════════════════════════
#  VENTANA PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════
class MainWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Propi — Sistema de Facturación")
        self.configure(bg=BG_MAIN)
        self.state("zoomed")          # maximizada
        self.protocol("WM_DELETE_WINDOW", self._cerrar)   # la X también cierra sesión
        self._build()

    def _build(self):
        # Barra superior
        barra = tk.Frame(self, bg=COLOR_ACC, height=48)
        barra.pack(fill="x")
        tk.Label(barra, text="  Propi Facturación", font=FONT_H2,
                 bg=COLOR_ACC, fg="white").pack(side="left", padx=8, pady=10)
        _btn(barra, "Cerrar sesión", self._cerrar, color="#174E8A").pack(side="right", padx=12, pady=8)

        # Notebook (pestañas)
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=12, pady=12)

        self._tab_clientes(nb)
        self._tab_facturas(nb)
        self._tab_notas(nb)
        self._tab_reportes(nb)

    def _cerrar(self):
        login = self.master
        try:
            db.cerrar_acceso()
            db.desconectar()
        finally:
            self.destroy()
            login.volver()

    # ── TAB: Clientes ─────────────────────────────────────────────────────────
    def _tab_clientes(self, nb):
        frame = tk.Frame(nb, bg=BG_FRAME)
        nb.add(frame, text="  Clientes  ")

        # Barra de herramientas
        bar = tk.Frame(frame, bg=BG_FRAME, pady=8)
        bar.pack(fill="x", padx=12)
        _lbl(bar, "Buscar:").pack(side="left")
        self.ent_buscar_cli = _entry(bar, width=28)
        self.ent_buscar_cli.pack(side="left", padx=6)
        _btn(bar, "Buscar", self._buscar_clientes).pack(side="left", padx=4)
        _btn(bar, "+ Nuevo cliente", self._nuevo_cliente).pack(side="left", padx=4)
        _btn(bar, "Editar seleccionado", self._editar_cliente).pack(side="left", padx=4)

        # Tabla
        cols = ["cod_cliente", "nom_cliente", "tipo_identificacion",
                "num_identificacion", "provincia", "canton", "correo", "estado"]
        frm_tv, self.tv_clientes = _tabla(frame, cols, alto=16)
        frm_tv.pack(fill="both", expand=True, padx=12, pady=4)

        self._buscar_clientes()

    def _buscar_clientes(self):
        try:
            filtro = self.ent_buscar_cli.get()
            filas  = db.listar_clientes(filtro_nombre=filtro)
            _poblar_tabla(self.tv_clientes, filas)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _nuevo_cliente(self):
        FormCliente(self, cod_cliente=None, on_guardado=self._buscar_clientes)

    def _editar_cliente(self):
        sel = self.tv_clientes.selection()
        if not sel:
            messagebox.showwarning("Selección", "Seleccione un cliente de la lista.")
            return
        cod = int(self.tv_clientes.item(sel[0])["values"][0])
        FormCliente(self, cod_cliente=cod, on_guardado=self._buscar_clientes)

    # ── TAB: Facturas ─────────────────────────────────────────────────────────
    def _tab_facturas(self, nb):
        frame = tk.Frame(nb, bg=BG_FRAME)
        nb.add(frame, text="  Facturas  ")

        bar = tk.Frame(frame, bg=BG_FRAME, pady=8)
        bar.pack(fill="x", padx=12)
        _btn(bar, "+ Nueva factura", self._nueva_factura).pack(side="left", padx=4)
        _btn(bar, "Ver detalle", self._ver_factura).pack(side="left", padx=4)
        _btn(bar, "Actualizar lista", self._cargar_facturas).pack(side="left", padx=4)

        cols = ["num_factura", "nom_cliente", "fec_factura",
                "condicion_venta", "medio_pago", "moneda",
                "subtotal", "impuestos", "total"]
        frm_tv, self.tv_facturas = _tabla(frame, cols, alto=16)
        frm_tv.pack(fill="both", expand=True, padx=12, pady=4)
        self._cargar_facturas()

    def _cargar_facturas(self):
        try:
            filas = db.listar_facturas()
            _poblar_tabla(self.tv_facturas, filas)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _nueva_factura(self):
        FormFactura(self, on_guardado=self._cargar_facturas)

    def _ver_factura(self):
        sel = self.tv_facturas.selection()
        if not sel:
            messagebox.showwarning("Selección", "Seleccione una factura.")
            return
        num = int(self.tv_facturas.item(sel[0])["values"][0])
        DetalleFactura(self, num)

    # ── TAB: Notas de Crédito/Débito ─────────────────────────────────────────
    def _tab_notas(self, nb):
        frame = tk.Frame(nb, bg=BG_FRAME)
        nb.add(frame, text="  Notas C/D  ")

        bar = tk.Frame(frame, bg=BG_FRAME, pady=8)
        bar.pack(fill="x", padx=12)
        _lbl(bar, "Nº Factura:").pack(side="left")
        self.ent_fact_nota = _entry(bar, width=10)
        self.ent_fact_nota.pack(side="left", padx=6)
        _btn(bar, "Buscar notas", self._buscar_notas).pack(side="left", padx=4)
        _btn(bar, "+ Nueva nota", self._nueva_nota).pack(side="left", padx=4)

        cols = ["cod_nota", "fec_nota", "num_factura", "tipo", "motivo"]
        frm_tv, self.tv_notas = _tabla(frame, cols, alto=16)
        frm_tv.pack(fill="both", expand=True, padx=12, pady=4)
        self._buscar_notas()

    def _buscar_notas(self):
        try:
            txt = self.ent_fact_nota.get().strip()
            num = int(txt) if txt.isdigit() else None
            filas = db.listar_notas(num_factura=num)
            _poblar_tabla(self.tv_notas, filas)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _nueva_nota(self):
        FormNota(self, on_guardado=self._buscar_notas)

    # ── TAB: Reportes ─────────────────────────────────────────────────────────
    def _tab_reportes(self, nb):
        frame = tk.Frame(nb, bg=BG_FRAME)
        nb.add(frame, text="  Reportes  ")

        bar = tk.Frame(frame, bg=BG_FRAME, pady=8)
        bar.pack(fill="x", padx=12)
        _btn(bar, "Clientes resumen", self._rpt_clientes).pack(side="left", padx=4)
        _btn(bar, "Facturas", self._rpt_facturas).pack(side="left", padx=4)
        _btn(bar, "Pistas de auditoría", self._rpt_auditoria).pack(side="left", padx=4)

        self.frame_rpt = tk.Frame(frame, bg=BG_FRAME)
        self.frame_rpt.pack(fill="both", expand=True, padx=12, pady=4)

    def _mostrar_reporte(self, filas: list[dict]):
        for w in self.frame_rpt.winfo_children():
            w.destroy()
        if not filas:
            _lbl(self.frame_rpt, "Sin resultados.").pack()
            return
        cols = list(filas[0].keys())
        frm_tv, tv = _tabla(self.frame_rpt, cols, alto=18)
        frm_tv.pack(fill="both", expand=True)
        _poblar_tabla(tv, filas)

    def _error_reporte(self, e: Exception):
        # Error 229 = permiso EXECUTE denegado: el rol no puede ver ese reporte
        if "(229)" in str(e):
            messagebox.showwarning(
                "Sin permiso",
                "Su rol no tiene autorización para ver este reporte.\n"
                "Ingrese con un usuario del rol consulta o administrador.")
        else:
            messagebox.showerror("Error", str(e))

    def _rpt_clientes(self):
        try:
            self._mostrar_reporte(db.reporte_clientes())
        except Exception as e:
            self._error_reporte(e)

    def _rpt_facturas(self):
        try:
            self._mostrar_reporte(db.reporte_facturas())
        except Exception as e:
            self._error_reporte(e)

    def _rpt_auditoria(self):
        try:
            self._mostrar_reporte(db.reporte_pistas_auditoria())
        except Exception as e:
            self._error_reporte(e)


# ══════════════════════════════════════════════════════════════════════════════
#  FORMULARIO: CLIENTE (nuevo / editar)
# ══════════════════════════════════════════════════════════════════════════════
class FormCliente(tk.Toplevel):
    def __init__(self, parent, cod_cliente: int | None, on_guardado):
        super().__init__(parent)
        self.cod_cliente  = cod_cliente
        self.on_guardado  = on_guardado
        self.title("Nuevo cliente" if cod_cliente is None else f"Editar cliente #{cod_cliente}")
        self.configure(bg=BG_FRAME)
        self.resizable(False, False)
        self._tipos = db.listar_tipos_identificacion()
        self._datos = db.obtener_cliente(cod_cliente) if cod_cliente else {}
        self._build()
        self.grab_set()

    def _build(self):
        d = self._datos
        f = tk.Frame(self, bg=BG_FRAME, padx=28, pady=20)
        f.pack()

        tk.Label(f, text="Datos del cliente", font=FONT_H2,
                 bg=BG_FRAME, fg=COLOR_ACC).grid(row=0, column=0, columnspan=2, pady=(0, 16))

        self.e_nom       = _form_campo(f, 1,  "Nombre / Razón social", d.get("nom_cliente",""), 36)
        # Tipo de identificación
        _lbl(f, "Tipo identificación:").grid(row=2, column=0, sticky="e", padx=(0,8), pady=4)
        nombres_tipo = [f"{t['cod_tipo_identificacion']} - {t['des_tipo_identificacion']}"
                        for t in self._tipos]
        self.cb_tipo = ttk.Combobox(f, values=nombres_tipo, width=28, state="readonly")
        tipo_actual = d.get("cod_tipo_identificacion", 1)
        for i, t in enumerate(self._tipos):
            if t["cod_tipo_identificacion"] == tipo_actual:
                self.cb_tipo.current(i)
                break
        else:
            self.cb_tipo.current(0)
        self.cb_tipo.grid(row=2, column=1, sticky="w", pady=4)

        self.e_id        = _form_campo(f, 3,  "Número identificación", d.get("num_identificacion",""), 20)
        self.e_prov      = _form_campo(f, 4,  "Provincia",             d.get("nom_provincia",""), 24)
        self.e_canton    = _form_campo(f, 5,  "Cantón",                d.get("nom_canton",""), 24)
        self.e_distrito  = _form_campo(f, 6,  "Distrito",              d.get("nom_distrito",""), 24)
        self.e_barrio    = _form_campo(f, 7,  "Barrio (opcional)",     d.get("nom_barrio",""), 24)
        self.e_correo    = _form_campo(f, 8,  "Correo electrónico",    d.get("des_correo",""), 32)
        self.e_telefono  = _form_campo(f, 9,  "Teléfono (opcional)",   d.get("num_telefono",""), 18)
        self.e_profesion = _form_campo(f, 10, "Profesión (opcional)",  d.get("des_profesion",""), 28)
        self.e_actividad = _form_campo(f, 11, "Actividad económica",   d.get("des_actividad_economica",""), 36)

        bar = tk.Frame(f, bg=BG_FRAME)
        bar.grid(row=12, column=0, columnspan=2, pady=(20, 0))
        _btn(bar, "Guardar", self._guardar).pack(side="left", padx=6)
        _btn(bar, "Cancelar", self.destroy, color=FG_SUB).pack(side="left", padx=6)

    def _guardar(self):
        try:
            tipo_sel = self._tipos[self.cb_tipo.current()]
            kwargs = dict(
                nom_cliente=self.e_nom.get().strip(),
                cod_tipo_identificacion=tipo_sel["cod_tipo_identificacion"],
                num_identificacion=self.e_id.get().strip(),
                nom_provincia=self.e_prov.get().strip(),
                nom_canton=self.e_canton.get().strip(),
                nom_distrito=self.e_distrito.get().strip(),
                des_correo=self.e_correo.get().strip(),
                nom_barrio=self.e_barrio.get().strip(),
                des_profesion=self.e_profesion.get().strip(),
                des_actividad_economica=self.e_actividad.get().strip(),
                num_telefono=self.e_telefono.get().strip(),
            )
            if self.cod_cliente is None:
                cod = db.insertar_cliente(**kwargs)
                messagebox.showinfo("Éxito", f"Cliente creado con código {cod}.")
            else:
                # El SP exige todos los campos; el estado se conserva tal cual
                kwargs["ind_estado"] = self._datos.get("ind_estado") or "A"
                db.actualizar_cliente(cod_cliente=self.cod_cliente, **kwargs)
                messagebox.showinfo("Éxito", "Cliente actualizado.")
            self.on_guardado()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error al guardar", str(e))


# ══════════════════════════════════════════════════════════════════════════════
#  FORMULARIO: FACTURA
# ══════════════════════════════════════════════════════════════════════════════
class FormFactura(tk.Toplevel):
    def __init__(self, parent, on_guardado):
        super().__init__(parent)
        self.on_guardado = on_guardado
        self.title("Nueva factura")
        self.configure(bg=BG_FRAME)
        self.resizable(True, True)
        self._clientes  = db.listar_clientes()
        self._productos = db.listar_productos()
        self._lineas: list[dict] = []
        self._build()
        self.grab_set()

    def _build(self):
        # Encabezado
        top = tk.Frame(self, bg=BG_FRAME, padx=20, pady=16)
        top.pack(fill="x")

        tk.Label(top, text="Nueva factura", font=FONT_H2,
                 bg=BG_FRAME, fg=COLOR_ACC).grid(row=0, column=0, columnspan=4, pady=(0,12))

        _lbl(top, "Cliente:").grid(row=1, column=0, sticky="e", padx=(0,8), pady=4)
        nombres_cli = [f"{c['cod_cliente']} - {c['nom_cliente']}" for c in self._clientes]
        self.cb_cli = ttk.Combobox(top, values=nombres_cli, width=36, state="readonly")
        if self._clientes: self.cb_cli.current(0)
        self.cb_cli.grid(row=1, column=1, sticky="w", pady=4)

        _lbl(top, "Condición venta:").grid(row=2, column=0, sticky="e", padx=(0,8), pady=4)
        self.cb_cond = ttk.Combobox(top, values=["C - Contado", "R - Crédito"], width=18, state="readonly")
        self.cb_cond.current(0)
        self.cb_cond.grid(row=2, column=1, sticky="w", pady=4)

        _lbl(top, "Medio de pago:").grid(row=3, column=0, sticky="e", padx=(0,8), pady=4)
        self.cb_medio = ttk.Combobox(top,
            values=["E - Efectivo","T - Tarjeta","Q - Cheque",
                    "F - Transferencia","S - SINPE","O - Otros"],
            width=22, state="readonly")
        self.cb_medio.current(0)
        self.cb_medio.grid(row=3, column=1, sticky="w", pady=4)

        _lbl(top, "Moneda:").grid(row=4, column=0, sticky="e", padx=(0,8), pady=4)
        self.cb_moneda = ttk.Combobox(top, values=["CRC","USD"], width=8, state="readonly")
        self.cb_moneda.current(0)
        self.cb_moneda.grid(row=4, column=1, sticky="w", pady=4)

        _lbl(top, "Tipo cambio:").grid(row=5, column=0, sticky="e", padx=(0,8), pady=4)
        self.e_tc = _entry(top, width=12)
        self.e_tc.insert(0, "1")
        self.e_tc.grid(row=5, column=1, sticky="w", pady=4)

        _lbl(top, "Observaciones:").grid(row=6, column=0, sticky="e", padx=(0,8), pady=4)
        self.e_obs = _entry(top, width=40)
        self.e_obs.grid(row=6, column=1, sticky="w", pady=4)

        # Líneas de detalle
        tk.Label(self, text="Líneas de detalle", font=FONT_H2,
                 bg=BG_FRAME, fg=FG_SUB).pack(anchor="w", padx=20)

        bar_lin = tk.Frame(self, bg=BG_FRAME, padx=20)
        bar_lin.pack(fill="x", pady=4)
        _lbl(bar_lin, "Producto:").pack(side="left")
        nombres_prod = [f"{p['cod_producto']} - {p['des_producto']}" for p in self._productos]
        self.cb_prod = ttk.Combobox(bar_lin, values=nombres_prod, width=34, state="readonly")
        if self._productos: self.cb_prod.current(0)
        self.cb_prod.pack(side="left", padx=6)
        _lbl(bar_lin, "Cantidad:").pack(side="left")
        self.e_cant = _entry(bar_lin, width=8)
        self.e_cant.insert(0, "1")
        self.e_cant.pack(side="left", padx=6)
        _btn(bar_lin, "+ Agregar línea", self._agregar_linea).pack(side="left", padx=4)

        frm_lin, self.tv_lineas = _tabla(self, ["#", "Producto", "Cantidad", "Precio", "Monto"], alto=6)
        frm_lin.pack(fill="x", padx=20, pady=4)

        # Totales
        self.lbl_total = tk.Label(self, text="Total: ₡0.00", font=FONT_H2,
                                  bg=BG_FRAME, fg=COLOR_ACC)
        self.lbl_total.pack(anchor="e", padx=28, pady=6)

        bar_btn = tk.Frame(self, bg=BG_FRAME, pady=12)
        bar_btn.pack()
        _btn(bar_btn, "Guardar factura", self._guardar).pack(side="left", padx=6)
        _btn(bar_btn, "Cancelar", self.destroy, color=FG_SUB).pack(side="left", padx=6)

    def _agregar_linea(self):
        try:
            idx  = self.cb_prod.current()
            prod = self._productos[idx]
            cant = float(self.e_cant.get().strip())
            if cant <= 0:
                raise ValueError("La cantidad debe ser mayor que 0.")
            monto = round(cant * float(prod.get("mon_precio", 0)), 2)
            self._lineas.append({
                "cod_producto": prod["cod_producto"],
                "des_producto": prod["des_producto"],
                "num_cantidad": cant,
                "mon_precio":   float(prod.get("mon_precio", 0)),
                "mon_linea":    monto,
            })
            self.tv_lineas.insert("", "end", values=[
                len(self._lineas),
                prod["des_producto"],
                cant,
                prod.get("mon_precio", 0),
                monto,
            ])
            total = sum(l["mon_linea"] for l in self._lineas)
            self.lbl_total.config(text=f"Subtotal: {total:,.2f}")
        except Exception as e:
            messagebox.showerror("Error en línea", str(e))

    def _guardar(self):
        if not self._lineas:
            messagebox.showwarning("Sin líneas", "Agregue al menos una línea de detalle.")
            return
        try:
            cli   = self._clientes[self.cb_cli.current()]
            cond  = self.cb_cond.get()[0]      # "C" o "R"
            medio = self.cb_medio.get()[0]     # "E", "T", etc.
            mon   = self.cb_moneda.get()
            tc    = float(self.e_tc.get())
            obs   = self.e_obs.get().strip()
            lineas = [{"cod_producto": l["cod_producto"],
                       "num_cantidad": l["num_cantidad"]} for l in self._lineas]
            num = db.insertar_factura(
                cod_cliente=cli["cod_cliente"],
                ind_condicion_venta=cond,
                ind_medio_pago=medio,
                cod_moneda=mon,
                mon_tipo_cambio=tc,
                des_observaciones=obs,
                lineas=lineas,
            )
            messagebox.showinfo("Éxito", f"Factura #{num} creada correctamente.")
            self.on_guardado()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error al guardar factura", str(e))


# ══════════════════════════════════════════════════════════════════════════════
#  VENTANA: DETALLE DE FACTURA
# ══════════════════════════════════════════════════════════════════════════════
class DetalleFactura(tk.Toplevel):
    def __init__(self, parent, num_factura: int):
        super().__init__(parent)
        self.title(f"Factura #{num_factura}")
        self.configure(bg=BG_FRAME)
        self.resizable(True, True)
        self._num = num_factura
        self._build()

    def _build(self):
        try:
            datos = db.obtener_factura(self._num)
        except Exception as e:
            tk.Label(self, text=str(e), fg=COLOR_ERR, bg=BG_FRAME, font=FONT_BODY).pack(padx=20, pady=20)
            return

        if not datos:
            tk.Label(self, text="Factura no encontrada.", bg=BG_FRAME).pack(padx=20, pady=20)
            return

        f = tk.Frame(self, bg=BG_FRAME, padx=24, pady=20)
        f.pack(fill="both", expand=True)

        tk.Label(f, text=f"Factura #{self._num}", font=FONT_H1,
                 bg=BG_FRAME, fg=COLOR_ACC).pack(anchor="w", pady=(0, 12))

        for clave, valor in datos.items():
            row = tk.Frame(f, bg=BG_FRAME)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=f"{clave}:", width=22, anchor="e",
                     bg=BG_FRAME, fg=FG_SUB, font=FONT_BODY).pack(side="left")
            tk.Label(row, text=str(valor) if valor is not None else "—",
                     bg=BG_FRAME, fg=FG_MAIN, font=FONT_BODY).pack(side="left", padx=8)


# ══════════════════════════════════════════════════════════════════════════════
#  FORMULARIO: NOTA DE CRÉDITO/DÉBITO
# ══════════════════════════════════════════════════════════════════════════════
class FormNota(tk.Toplevel):
    def __init__(self, parent, on_guardado):
        super().__init__(parent)
        self.on_guardado = on_guardado
        self.title("Nueva nota de crédito/débito")
        self.configure(bg=BG_FRAME)
        self.resizable(False, False)
        self._build()
        self.grab_set()

    def _build(self):
        f = tk.Frame(self, bg=BG_FRAME, padx=28, pady=20)
        f.pack()

        tk.Label(f, text="Nueva nota de crédito / débito", font=FONT_H2,
                 bg=BG_FRAME, fg=COLOR_ACC).grid(row=0, column=0, columnspan=2, pady=(0, 16))

        self.e_num = _form_campo(f, 1, "Número de factura", "", 12)

        _lbl(f, "Tipo de nota:").grid(row=2, column=0, sticky="e", padx=(0,8), pady=4)
        self.cb_tipo = ttk.Combobox(f, values=["C - Crédito", "D - Débito"], width=18, state="readonly")
        self.cb_tipo.current(0)
        self.cb_tipo.grid(row=2, column=1, sticky="w", pady=4)

        _lbl(f, "Motivo:").grid(row=3, column=0, sticky="ne", padx=(0,8), pady=4)
        self.txt_motivo = tk.Text(f, width=36, height=4, font=FONT_BODY, relief="solid", bd=1)
        self.txt_motivo.grid(row=3, column=1, sticky="w", pady=4)

        bar = tk.Frame(f, bg=BG_FRAME)
        bar.grid(row=4, column=0, columnspan=2, pady=(16, 0))
        _btn(bar, "Guardar nota", self._guardar).pack(side="left", padx=6)
        _btn(bar, "Cancelar", self.destroy, color=FG_SUB).pack(side="left", padx=6)

    def _guardar(self):
        try:
            num_str = self.e_num.get().strip()
            if not num_str.isdigit():
                raise ValueError("Ingrese un número de factura válido.")
            tipo   = self.cb_tipo.get()[0]   # "C" o "D"
            motivo = self.txt_motivo.get("1.0", "end").strip()
            if not motivo:
                raise ValueError("El motivo no puede estar vacío.")
            db.insertar_nota(int(num_str), tipo, motivo)
            messagebox.showinfo("Éxito", "Nota registrada correctamente.")
            self.on_guardado()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error al guardar nota", str(e))


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRADA PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = LoginWindow()
    app.mainloop()
