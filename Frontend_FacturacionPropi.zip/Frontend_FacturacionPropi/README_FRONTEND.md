# Frontend — PropiFacturacion
**Python + tkinter** · REQ 002 · Grupo 22

## Requisitos
- Python 3.11 o superior (tkinter viene incluido)
- ODBC Driver 17 o 18 para SQL Server  
  → Descargar en https://learn.microsoft.com/es-es/sql/connect/odbc/download-odbc-driver-for-sql-server

```
pip install pyodbc
```

## Configuración
Editar `config.ini` antes de ejecutar:

```ini
[database]
server    = localhost          # nombre o IP del servidor SQL
database  = PropiFacturacion
usuario   = propi_digitador    # o propi_admin / propi_consulta
contrasena = Propi_Digitador#2026!
driver    = ODBC Driver 17 for SQL Server
```

## Ejecutar
```
python app.py
```

## Estructura
```
frontend/
├── app.py          ← Ventanas y lógica de UI (tkinter)
├── db.py           ← Capa de datos: SOLO llama SPs, cero SQL concatenado
├── config.ini      ← Cadena de conexión (NO subir a Git con contraseñas reales)
└── requirements.txt
```

## Regla clave de seguridad
`db.py` **nunca** construye SQL con f-strings o concatenación.
Siempre usa parámetros (`?`) o ejecuta SPs por nombre:

```python
# ✅ CORRECTO — parametrizado
cur.execute("EXEC app.usp_Cliente_Insertar @nom_cliente=?, ...", valor)

# ❌ INCORRECTO — vulnerable a SQL injection
cur.execute(f"SELECT * FROM Cliente WHERE nombre = '{nombre}'")
```

## Pantallas disponibles
| Pestaña | Funciones |
|---------|-----------|
| Clientes | Listar, buscar, nuevo, editar |
| Facturas | Listar, nueva factura con líneas de detalle, ver detalle |
| Notas C/D | Listar por factura, nueva nota de crédito o débito |
| Reportes | Clientes resumen, facturas, pistas de auditoría |
